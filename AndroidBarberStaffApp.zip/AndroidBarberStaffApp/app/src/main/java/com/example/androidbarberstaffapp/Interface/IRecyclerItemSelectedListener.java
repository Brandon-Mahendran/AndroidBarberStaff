package com.example.androidbarberstaffapp.Interface;

import android.view.View;

public interface IRecyclerItemSelectedListener {
    void onItemSelected(View view, int position);
}
