package com.example.androidbarberstaffapp.Common;

public class Common {
    public static String state_name="";
}
